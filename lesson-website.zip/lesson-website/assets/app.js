/* =====================
   app.js — Main Logic
   ===================== */

// ---- Animated counters ----
function animateCounter(el, target, duration = 1200) {
  let start = 0;
  const step = target / (duration / 16);
  const timer = setInterval(() => {
    start = Math.min(start + step, target);
    el.textContent = Math.round(start);
    if (start >= target) clearInterval(timer);
  }, 16);
}

window.addEventListener('DOMContentLoaded', () => {
  const totalLessons = SUBJECTS.reduce((s, sub) => s + sub.lessons.length, 0);
  animateCounter(document.getElementById('stat-subjects'), SUBJECTS.length);
  animateCounter(document.getElementById('stat-lessons'), totalLessons);

  renderSubjects(SUBJECTS);
  initSearch();
  initModal();
  initMobileNav();
});

// ---- Render subject cards ----
function renderSubjects(subjects) {
  const grid = document.getElementById('subjectsGrid');
  grid.innerHTML = '';

  if (subjects.length === 0) {
    grid.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">🔍</div>
        <h3>ไม่พบวิชาที่ค้นหา</h3>
        <p>ลองค้นหาด้วยคำอื่น หรือดูวิชาทั้งหมด</p>
      </div>`;
    return;
  }

  subjects.forEach(sub => {
    const card = document.createElement('div');
    card.className = 'subject-card';
    card.setAttribute('data-id', sub.id);
    card.innerHTML = `
      <div class="card-top" style="background:${sub.colorLight}; color:${sub.color}">
        <span style="filter:drop-shadow(0 4px 8px ${sub.color}44)">${sub.icon}</span>
      </div>
      <div class="card-body">
        <div class="card-subject-name" style="color:${sub.color}">${sub.name}</div>
        <div class="card-desc">${sub.desc}</div>
        <div class="card-lessons-count">📄 ${sub.lessons.length} บทเรียน</div>
        <ul class="lesson-list">
          ${sub.lessons.slice(0, 3).map(l => `
            <li class="lesson-item" data-url="${l.url}" data-type="${l.type}">
              <span>${lessonIcon(l.type)}</span>
              <span style="flex:1;font-size:0.9rem">${l.title}</span>
              <span class="lesson-type-badge ${badgeClass(l.type)}">${typeLabel(l.type)}</span>
            </li>
          `).join('')}
          ${sub.lessons.length > 3 ? `
            <li class="lesson-item" style="justify-content:center;color:var(--purple);font-size:0.9rem">
              ดูทั้งหมด ${sub.lessons.length} บทเรียน →
            </li>` : ''}
        </ul>
      </div>`;
    card.addEventListener('click', (e) => {
      // if clicked on a lesson item, open that lesson directly
      const lessonEl = e.target.closest('.lesson-item[data-url]');
      if (lessonEl) {
        e.stopPropagation();
        openLesson(lessonEl.dataset.url, lessonEl.dataset.type);
        return;
      }
      openModal(sub);
    });
    grid.appendChild(card);
  });
}

function lessonIcon(type) {
  return type === 'pdf' ? '📄' : type === 'img' ? '🖼️' : '🔗';
}
function typeLabel(type) {
  return type === 'pdf' ? 'PDF' : type === 'img' ? 'รูปภาพ' : 'ลิงก์';
}
function badgeClass(type) {
  return type === 'pdf' ? 'badge-pdf' : type === 'img' ? 'badge-img' : 'badge-link';
}

// ---- Search ----
function initSearch() {
  const input = document.getElementById('searchInput');
  input.addEventListener('input', () => {
    const q = input.value.trim().toLowerCase();
    if (!q) { renderSubjects(SUBJECTS); return; }
    const filtered = SUBJECTS.filter(sub =>
      sub.name.toLowerCase().includes(q) ||
      sub.desc.toLowerCase().includes(q) ||
      sub.lessons.some(l => l.title.toLowerCase().includes(q))
    );
    renderSubjects(filtered);
  });
}

// ---- Modal ----
function initModal() {
  document.getElementById('modalClose').addEventListener('click', closeModal);
  document.getElementById('modalOverlay').addEventListener('click', (e) => {
    if (e.target === document.getElementById('modalOverlay')) closeModal();
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });
}

function openModal(sub) {
  document.getElementById('modalHeader').innerHTML = `
    <h2>${sub.icon} ${sub.name}</h2>
    <p>${sub.desc}</p>
  `;
  document.getElementById('modalBody').innerHTML = `
    <div class="modal-lesson-list">
      ${sub.lessons.map((l, i) => `
        <a class="modal-lesson-item" href="${l.url}" target="_blank" rel="noopener">
          <span class="lesson-icon">${lessonIcon(l.type)}</span>
          <div class="lesson-info">
            <div class="lesson-title">${l.title}</div>
            <div class="lesson-meta">${l.desc}</div>
          </div>
          <span class="lesson-action lesson-type-badge ${badgeClass(l.type)}">${typeLabel(l.type)} →</span>
        </a>
      `).join('')}
    </div>
  `;
  document.getElementById('modalOverlay').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  document.getElementById('modalOverlay').classList.remove('open');
  document.body.style.overflow = '';
}

function openLesson(url, type) {
  window.open(url, '_blank', 'noopener');
}

// ---- Mobile nav ----
function initMobileNav() {
  const toggle = document.getElementById('menuToggle');
  const nav = document.getElementById('mobileNav');
  toggle.addEventListener('click', () => nav.classList.toggle('open'));
  nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));
}
